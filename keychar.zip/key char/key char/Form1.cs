﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace key_char
{
    public partial class Form1 : Form
    {
        public static char backspace = (char)Keys.Back;
        public char keychar = 'A';
        TextWriter txt = new StreamWriter("track.txt");
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Key Pressed: ";
            label2.Text = "Key Info: ";
            label3.Text = "";
            txt.WriteLine("-------------------------------------------------------------------------------");
            txt.WriteLine("ALT|SHIFT|CTRL|KEYCHAR|KEYCODE           |KEYDATA                    |KEYVALUE|");
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Back)
            {
                label2.Text =
                    "Key Info: " + '\n' +
                    "Alt: " + (e.Alt ? "Yes" : "No") + '\n' +
                    "Shift: " + (e.Shift ? "Yes" : "No") + '\n' +
                    "Ctrl: " + (e.Control ? "Yes" : "No") + '\n' +
                    "KeyCode: " + e.KeyCode + '\n' +
                    "KeyData: " + e.KeyData + '\n' +
                    "KeyValue: " + e.KeyValue;
            }
            

            if (e.KeyCode == Keys.Back)
            {
                if (((label3.Text).Length) > 0)
                {
                    label3.Text = (label3.Text).Remove((label3.Text).Length - 1);

                }
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != backspace)
            {
                label1.Text = "Key Pressed: " + e.KeyChar;
                label3.Text += e.KeyChar.ToString();
                keychar = e.KeyChar;
            }

            
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (label3.Text.Contains(backspace))
            {
                label3.Text = label3.Text = (label3.Text).Remove((label3.Text).Length - 1);
            }

            string key_char = "";
            string key_code = e.KeyCode.ToString();
            string key_data = e.KeyData.ToString();
            string key_value = e.KeyValue.ToString();


            if (keychar.ToString().Length == 0)
            {
                key_char = "       |";
            }
            else
            {
                key_char = keychar + "      |";
            }
            
            for (int i = 0; i < 18- e.KeyCode.ToString().Length; i++)
            {
                    key_code += " ";
            }
            key_code += "|";

            for (int i = 0; i < 27 - e.KeyData.ToString().Length; i++)
            {
                key_data += " ";
            }
            key_data += "|";

            for (int i = 0; i < 8 - e.KeyValue.ToString().Length; i++)
            {
                key_value += " ";
            }
            key_value += "|";

            txt.WriteLine((e.Alt ? "Yes|" : "No |")+ (e.Shift ? "Yes  |" : "No   |")+ (e.Control ? "Yes |" : "No  |")+(key_char)+(key_code)+(key_data)+(key_value));
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            txt.WriteLine("-------------------------------------------------------------------------------");
            txt.WriteLine("Final String: "+label3.Text);
            txt.Close();
        }
    }
}
